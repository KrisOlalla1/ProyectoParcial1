class MenuComponent extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({mode: 'open'});
    }

    connectedCallback() {
        this.render();
    }

    render() {
        this.shadowRoot.innerHTML = `
            <style>
                nav {
                    background-color: #333;
                    color: white;
                    padding: 10px;
                }
                nav a {
                    color: white;
                    text-decoration: none;
                    margin-right: 15px;
                    font-size: 16px;
                }
                nav a:hover {
                    text-decoration: underline;
                }
            </style>
            <nav>
                <a href="index.html" id="inicio-link">Inicio</a>
                <a href="estudiantes.html" id="estudiantes-link">Estudiantes</a>
                <a href="clubs.html" id="clubs-link">Clubs</a>
                <a href="miembros.html" id="miembros-link">Miembros</a>
                <a href="acerca.html" id="acerca-link">Acerca de</a>
            </nav>
        `;
    }
}

customElements.define('menu-component', MenuComponent);
